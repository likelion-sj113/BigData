package com.java.customer.service;

public interface ICustomerService {
	String run(String name);
}
