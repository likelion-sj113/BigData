package com.java.cust.controller;

import com.java.cust.service.ICustomerService;

public class CustomerController {
	
	ICustomerService custService;
	
	public void setCustomerService(ICustomerService custService) {
		this.custService = custService;
	}
	
	public void run(String name) {
		System.out.println("HelloController : " + custService.run(name));
	}
}