package com.java.cust;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.java.cust.controller.CustomerController;

public class CustomerMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = new GenericXmlApplicationContext("application-config.xml");
		CustomerController custController = (CustomerController)context.getBean("custController");
		
		custController.run("com.j");
	}
}
