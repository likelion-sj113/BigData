package com.java.cust.service;

public interface ICustomerService {
	String run(String name);
}
