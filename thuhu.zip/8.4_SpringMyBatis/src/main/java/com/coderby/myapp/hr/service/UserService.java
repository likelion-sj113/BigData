package com.coderby.myapp.hr.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.coderby.myapp.hr.dao.IUserRepository;
import com.coderby.myapp.hr.model.UserInfo;


@Service
public class UserService implements IUserService {
	@Autowired
	@Qualifier("IUserRepository")
	IUserRepository userRepository;

	@Override
	public void LoginUser(UserInfo user) {
		// TODO Auto-generated method stub
		userRepository.LoginUser(user);
	}

	@Override
	public void JoinUser(UserInfo user) {
		// TODO Auto-generated method stub
		userRepository.JoinUser(user);
	}
}