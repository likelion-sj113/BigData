package com.coderby.myapp.hr.model;

public class UserInfo {
	private String userName;
	private String userId;
	private String userPw;
	private String email;
	private String phone;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserPw() {
		return userPw;
	}


	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "UserInfo [userName=" + userName + ", userId=" + userId + ", userPw =" + userPw 
				+ ", email=" + email + ", phone=" + phone + "]";
	}

}
