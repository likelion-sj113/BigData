package com.coderby.myapp.hr.dao;

import java.util.List;

import com.coderby.myapp.hr.model.UserInfo;

public interface IUserRepository {

	void LoginUser(UserInfo user);
	void JoinUser(UserInfo user);
}
