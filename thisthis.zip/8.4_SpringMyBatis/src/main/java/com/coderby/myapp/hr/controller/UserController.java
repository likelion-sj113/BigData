package com.coderby.myapp.hr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.coderby.myapp.hr.model.UserInfo;
import com.coderby.myapp.hr.service.IUserService;

@Controller
public class UserController {
	@Autowired
	IUserService userService;
	
	@RequestMapping(value="/join", method=RequestMethod.GET)
	public String JoinUser(Model model) {
		return "/user/JoinForm";
	}
	
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String JoinUser(UserInfo user, Model model) {
		userService.JoinUser(user);
		return "redirect:/";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String LoginUser(Model model) {
		return "/user/LoginForm";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String LoginUser(UserInfo user, Model model) {
		userService.LoginUser(user);
		return "redirect:/";
	}
}
