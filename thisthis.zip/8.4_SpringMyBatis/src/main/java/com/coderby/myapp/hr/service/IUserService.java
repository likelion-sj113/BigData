package com.coderby.myapp.hr.service;

import java.util.List;

import com.coderby.myapp.hr.model.UserInfo;

public interface IUserService {
	//List<UserInfo> getUserList();
	void LoginUser(UserInfo user);
	void JoinUser(UserInfo user);
	//void InsertUser(UserInfo user);
}
